# -*- coding: utf-8 -*-
"""
Created on Sun Oct 21 10:04:45 2018

@author: Administrator
"""

import cv2
lena=cv2.imread("lena2.bmp")

